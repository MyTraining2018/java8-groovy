package org.cap.dateDemo;

import java.util.StringJoiner;

public class StringDemo {

	public static void main(String[] args) {
		//StringJoiner joiner=new StringJoiner(",");
		/*StringJoiner joiner=new StringJoiner(",","{","}");
		joiner.add("Tom");
		joiner.add("Tim");
		joiner.add("Jack");
		joiner.add("Annie");
		
		System.out.println(joiner.toString()); */
		
	//	String string=new String();
		String s=String.join(",", "tom","leena","llily");
		System.out.println(s);
	}

}
