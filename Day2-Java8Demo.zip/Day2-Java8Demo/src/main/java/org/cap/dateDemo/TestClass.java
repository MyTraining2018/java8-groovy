package org.cap.dateDemo;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalUnit;
import java.util.Date;
import java.util.Set;

public class TestClass {

	public static void main(String[] args) {
		/*System.out.println(Instant.now());
		System.out.println(Instant.MIN);
		System.out.println(Instant.MAX);*/
		
		/*System.out.println(LocalDate.now());
		System.out.println(LocalDate.of(1990, Month.AUGUST, 23));
		
		LocalDate birthDate=LocalDate.of(1990, Month.AUGUST, 23);
		*/
		//System.out.println(Duration.between(LocalDate.now(), LocalDate.of(1990, Month.AUGUST, 23)));
		/*System.out.println(LocalDate.now().getYear());
		
		Period period=birthDate.until(LocalDate.now());
		
		System.out.println("years:" + period.getYears());
		System.out.println("Months:" + period.getMonths());
		System.out.println("Days:" + period.getDays());
		
		System.out.println("Months:" + period.get(ChronoUnit.MONTHS));
		
		
		long months =birthDate.until(LocalDate.now(),ChronoUnit.MONTHS);
		
		System.out.println(months);
		
		long days =birthDate.until(LocalDate.now(),ChronoUnit.DAYS);
		
		System.out.println(days);*/
		
		
		
		
		
		
		
		
		/*System.out.println(LocalTime.now());
		
		LocalTime meeting= LocalTime.of(23, 34, 12);
		
		System.out.println("BedTime:" + meeting.minusHours(4));
		*/
		
		/*Set<String> zones=ZoneId.getAvailableZoneIds();
		System.out.println("Total: " + zones.size());
		
		for(String zone:zones)
			System.out.println(zone);
		
		
		System.out.println(ZonedDateTime.of(1990, 5, 23, 10, 23, 45, 90, ZoneId.of("Europe/Paris")));
		*/
		
		Instant now=Instant.now();
		Instant myDate=Instant.MIN;
		
		System.out.println(Duration.between(now, myDate));
	
		System.out.println(Duration.ofHours(100));
		
		Date date=new Date(2018, 2, 22);
		
		
		Duration duration=Duration.ofMillis(date.getTime());
		System.out.println(duration.toMillis());
		System.out.println(duration.toDays());
		System.out.println(duration.toHours());
		
	}

}
