package org.cap.dateDemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class Comparatordemo {

	public static void main(String[] args) {
		
		
		List<Person> persons=new ArrayList<>();
		
		try (
	            BufferedReader reader = 
	                new BufferedReader(
	                    new InputStreamReader(
	                    		PersonAge.class.getResourceAsStream("people.txt")));
	            Stream<String> stream = reader.lines();
	        ){
            
            stream.map(
               line -> {
                   String[] s = line.split(" ");
                   String name = s[0].trim();
                   int year = Integer.parseInt(s[1]);
                   Month month = Month.of(Integer.parseInt(s[2]));
                   int day = Integer.parseInt(s[3]);
                   Person p = new Person(name, LocalDate.of(year, month, day));
                   persons.add(p);
                   return p;
               })
              .forEach(System.out::println);
            
        } catch (IOException ioe) {
            System.out.println(ioe);
        }
		
		
		persons.add(new Person("Hari", null));
		persons.add(new Person("Kamal"));
		persons.add(new Person("HJack"));
		persons.add(new Person("Thomson"));
		
		persons.add(new Person( null,LocalDate.now()));
		persons.add(new Person( null,LocalDate.now()));
		persons.add(new Person( null,LocalDate.of(1991,2,12)));
		persons.add(new Person( null,LocalDate.of(1980,2,12)));
		
		
	
		Comparator<Person> comparator=
			Comparator.comparing(Person::getDateOfBirth).reversed();
				Comparator.nullsFirst(Comparator.naturalOrder());
			//	Comparator.nullsLast(Comparator.naturalOrder());
		
		
		persons.sort(comparator);
		
		System.out.println("===============================");
		
		persons.stream()
			.forEach(System.out::println);
		
		
		
	}

}
