package org.cap.dateDemo;

import java.util.HashMap;
import java.util.Map;

public class MapDemo {

	public static void main(String[] args) {
		Map<Integer, String> maps=new HashMap<>();
		maps.put(11, "Tom");
		maps.put(2, "Jack");
		maps.putIfAbsent(1, "Annie");
		
		
		System.out.println(maps);
		int num;
		
		//maps.computeIfPresent(2, num= 2 -> "Kamal");
		
		System.out.println(maps);
		

	}

}
