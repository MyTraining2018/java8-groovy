package org.cap.dateDemo;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class FileIODemo {

	public static void main(String[] args) {
		
		Path path=Paths.get("d:", "vidavid");
		
		try( Stream<Path> stream= Files.walk(path,2)){
			
			
			stream
			.filter(path1 -> path1.toFile().isDirectory())
			.forEach(System.out::println);
		}catch (Exception e) {
			System.out.println(e);
		}

	}

}
