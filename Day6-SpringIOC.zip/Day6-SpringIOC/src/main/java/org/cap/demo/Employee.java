package org.cap.demo;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;

public class Employee {
	
	private int employeeId;
	private String firstName;
	private String lastName;
	
	//@Autowired --> setter based injection
	private Address address;
	
	public Employee() {
		System.out.println("Employee Constructor");
	}
	
	//@Autowired
	//@Qualifier("address2")
	public Employee(int employeeId, String firstName, String lastName, Address address) {
		super();
		System.out.println("Employee Overloaded Constructor");
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
	}


	public int getEmployeeId() {
		return employeeId;
	}
	
	//@Required
	public void setEmployeeId(int employeeId) {
		//System.out.println("Hello-->EmployeeID");
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		//System.out.println("Hello-->FirstName");
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
	//	System.out.println("Hello-->LastName");
		this.lastName = lastName;
	}
	public Address getAddress() {
		return address;
	}
	
	
	public void setAddress(Address address) {
		//System.out.println("Hello-->Address");
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", address=" + address + "]";
	}
	
	
	
	@PostConstruct
	public void init() {
		System.out.println("bean initialized...");
	}
	
	
	@PreDestroy
	public void destroy() {
		System.out.println("bean Destroy.....");
	}
	
	
}
