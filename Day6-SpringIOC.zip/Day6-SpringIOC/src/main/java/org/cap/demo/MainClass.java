package org.cap.demo;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("beanConfig.xml");
		
		Employee employee=(Employee)context.getBean("employee");
		
		System.out.println(employee);
		
		context.close();
	}

}
