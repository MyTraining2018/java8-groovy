package org.cap.demo;

import java.util.function.BiFunction;
import java.util.function.Function;

interface Sayable {
	void say();
}

public class Arithmetic implements Sayable{
	
	public static void method() {
		System.out.println("Arithmentic Functions");
	}
	
	public int add(int num1,int num2) {
		return num1+num2;
	}
	
	
	public float add(int num1,float num2) {
		return num1+num2;
	}
	
	public float add(float num1,float num2) {
		return num1+num2;
	}
	
	
	public void print() {
		System.out.println("Printing Arithmetic Fucntions");
	}
	
	
	
	public static void main(String...args) {
		
		//Static method
		Sayable say=Arithmetic::method;
		
		//instance Method
		Arithmetic arithmetic=new Arithmetic();
		Sayable print =arithmetic::print;
		 
		
		say.say();
		
		print.say();
		
		
		
		
		BiFunction<Integer, Integer, Integer> function=arithmetic::add;
		Integer answer=function.apply(34, 90);
		System.out.println(answer);
		
		
		BiFunction<Integer, Float, Float> function1=arithmetic::add;
		Float answer1=function1.apply(34, 90.23f);
		System.out.println(answer1);
		
		//Constructor Method References
		Sayable arithmetic2=Arithmetic::new;
		
		System.out.println(arithmetic2);
		arithmetic2.say();
		
		
		
	}

	@Override
	public void say() {
		System.out.println("Arithmentic Functions --> Sayable Overiden");
		
	}

}
