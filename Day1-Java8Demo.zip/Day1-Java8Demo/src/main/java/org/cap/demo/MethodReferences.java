package org.cap.demo;

import java.util.Arrays;
import java.util.List;

public class MethodReferences {

	public static void main(String[] args) {
		
		List<String> list=Arrays.asList("one","two","three","four");
		
		/*for(String str:list)
			System.out.println(str);*/
		
		//list.forEach(System.out::println);
		
		list.forEach(s->System.out.println(s));
		

	}

}
