package org.cap.demo;

public class MyClass implements Message{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public String say() {
		return "Hello from MyClass!";
		
	}
	
	/*@Override
	static String greet() {
		return "hello! from MyClass";
	}*/
	
	public static void main(String[] args) {
		Message message=new MyClass();
		System.out.println(message.say());
		System.out.println(Message.greet());
	}

}
