package org.cap.demo;

@FunctionalInterface
public interface Message {
	
	//abstract method
	void show();
	
	default String say() {
		return "Good Morning!";
	}
	
	static String greet() {
		return "hello!";
	}

}
