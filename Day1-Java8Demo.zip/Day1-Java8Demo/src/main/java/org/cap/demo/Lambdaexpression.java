package org.cap.demo;

import java.io.File;
import java.io.FileFilter;

public class Lambdaexpression {

	public static void main(String[] args) {
		
		/*FileFilter filter=new FileFilter() {
			
			@Override
			public boolean accept(File pathname) {
				
				return pathname.getName().endsWith(".java");
			}
		};*/
		
		//FileFilter filter=(File pathname)->pathname.getName().endsWith(".java");
		
		FileFilter filter=(pathname)->{
			return pathname.getName().endsWith(".java");
		};
		
		File file=new File("D:\\vidavid\\Training\\2018\\ANZ_28_May_to_4_Jun\\demo\\Java8-Demo\\src\\main\\java\\org\\cap\\demo");
		
		File[] files=file.listFiles(filter);
		
		
		for(File f:files) {
			System.out.println(f);
		}
		
	}

}
