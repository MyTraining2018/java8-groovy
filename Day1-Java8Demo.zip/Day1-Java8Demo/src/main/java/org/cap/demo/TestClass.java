package org.cap.demo;

public class TestClass {

	public static void main(String[] args) {
		
		
		//Annonymous Object
	/*	Runnable runnable=new Runnable() {
			
			@Override
			public void run() {
				System.out.println("Hello world! ->" + Thread.currentThread().getName());
				
			}
		};
		*/
		
		//Lambda expressions
		Runnable runnable=() -> System.out.println("Hello world! ->" + Thread.currentThread().getName());
		
		Thread thread=new Thread(runnable);
		thread.start();
		

	}

}
