package org.cap.streamdemo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class CollectorDemo {

	public static void main(String[] args) {
		List<Person> persons=new ArrayList<>();

		persons.add(new Person("Jack", 23));
		persons.add(new Person("Annie", 12));
		persons.add(new Person("Kiran", 19));
		persons.add(new Person("Kamal", 23));
		persons.add(new Person("Jessie", 22));
		persons.add(new Person("Thomson", 23));
		persons.add(new Person("Clara", 32));
		persons.add(new Person("Tim", 55));
		persons.add(new Person("Tom", 55));
		
		Predicate<Person> p1= p -> p.getAge() >20;
		
		//String names
		List<String> names=persons.stream()
			.filter(p1)
			.map(p -> p.getName())
			.collect(
					// Collectors.joining(",")
					Collectors.toList()
					);
		
		System.out.println(names);
		
		
	//Grouping Age	
//	Map<Integer, List<Person>> result=persons.stream()
		
	Map<Integer, Long> result=persons.stream()	
		.filter(p1)
		//.collect(Collectors.groupingBy(Person::getAge));
		.collect(Collectors.groupingBy(
					Person::getAge,
					Collectors.counting()
				));
	
	System.out.println(result);

	}

}
