package org.cap.streamdemo;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Demo {

	public static void main(String[] args) {
		
		List<Person> persons=new ArrayList<>();

		persons.add(new Person("Jack", 23));
		persons.add(new Person("Annie", 12));
		persons.add(new Person("Kiran", 19));
		persons.add(new Person("Kamal", 45));
		persons.add(new Person("Jessie", 22));
		persons.add(new Person("Thomson", 33));
		persons.add(new Person("Clara", 32));
		persons.add(new Person("Tim", 11));
		persons.add(new Person("Tom", 55));
		
		List<Person> result=new ArrayList<>();
		List<Integer>  ages=new ArrayList<>();
		
		//Stream<Person> stream=persons.stream();
		
		Predicate<Person> p1= p -> p.getAge() >20;
		
		
		//Whole list refered as a stream
		persons.stream()
			.peek(System.out::println)
			.map(p -> p.getAge())
			.forEach(ages::add);
		//	.filter(p1)
			//.forEach(result::add);
		
		System.out.println("===================");
		
		//result.forEach(System.out::println);
		System.out.println(ages);
		 
		
		
		
	}

}
