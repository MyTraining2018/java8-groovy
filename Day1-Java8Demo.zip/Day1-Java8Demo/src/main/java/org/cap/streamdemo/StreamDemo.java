package org.cap.streamdemo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class StreamDemo {

	public static void main(String[] args) {
		
		
		List<String> list=Arrays.asList("*","****","***","*****");
		
		List<String> result=new ArrayList<>();
		
		//Stream
		Stream<String> stream=list.stream();
		
		//stream.forEach(s -> System.out.println(s));
		
		//stream.forEach(System.out::println);
		
		//Consumer<String> c1=s -> result.add(s);
		
		/*Consumer<String> c1=result::add;
		
		Consumer<String> c2=System.out::println;
		
		stream.forEach(c1.andThen(c2));*/
		
		Predicate<String> p1=s->s.length()>2;
		
		stream
			.peek(System.out::println)
			.filter(p1)
			.forEach(result::add);
		

		System.out.println(result);
		
	}

}
