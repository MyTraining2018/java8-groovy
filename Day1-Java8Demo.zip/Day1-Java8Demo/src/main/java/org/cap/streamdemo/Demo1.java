package org.cap.streamdemo;

import java.util.function.BinaryOperator;
import java.util.stream.Stream;

public class Demo1 {

	public static void main(String[] args) {
		//Stream<Integer> stream= Stream.of(1,2,3,4,5,6);

		//Stream<Integer> stream= Stream.empty();
		Stream<Integer> stream= Stream.empty();
		
		int id=0;
		BinaryOperator<Integer> add= (num1,num2) -> num1+num2;
		BinaryOperator<Integer> max= (num1,num2) -> num1>num2 ? num1 : num2;
		
		//int sum=stream.reduce(0, add);
	//	int maximum= stream.reduce(max);
		
		//System.out.println(sum);
		//System.out.println(maximum);
	}

}
