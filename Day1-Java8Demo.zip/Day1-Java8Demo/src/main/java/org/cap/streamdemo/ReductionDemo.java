package org.cap.streamdemo;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class ReductionDemo {

	public static void main(String[] args) {
		 List<Integer> list = Arrays.asList(1,34,56,78);
	        
	        Optional<Integer> red = 
	        list.stream()
	                .reduce(Integer::max);
	        
	        System.out.println("red = " + red);

	}

}
