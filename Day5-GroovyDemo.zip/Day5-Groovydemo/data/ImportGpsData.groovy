package org.cap.demo




def file=new File("./data/fells_loop.gpx")
//println file.exists()

def slurper=new XmlSlurper();
def gpx=slurper.parse(file)
//println gpx

println gpx.name
println gpx.desc

println ' '
println gpx.@version
println gpx.@creator

def points=gpx.rte.rtept


gpx.rte.rtept.each {
	println it.@lat
	println it.@lon
	println DateParser.parse(it.time)
	//println it.time
	/*def printableTime=new DateTime(it.time.toString())
	def format=DateTimeFormat.forPattern('MM/dd/yyyy - hh:mm aa')
	println printableTime.toString(format)*/
}
