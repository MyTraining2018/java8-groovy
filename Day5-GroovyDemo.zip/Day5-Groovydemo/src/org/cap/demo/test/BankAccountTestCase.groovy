package org.cap.demo.test

import org.cap.demo.BankAccount

class BankAccountTestCase extends GroovyTestCase{
	
	
	def testWhenDepositIncreaseBalance() {
		
		BankAccount account=new BankAccount(500);
		account.deposit(1000)
		
		assert 1500 == account.balance
	}
	

}
