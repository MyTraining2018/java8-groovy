package org.cap.demo

class BankAccount {
	
	private balance;
	
	public BankAccount(balance) {
		it.balance=balance;
	}

	
	def double deposit(amount) {
		return balance+=amount
	}
	
}
