package org.cap.demo

def myClosure= {
	println 'My Closure'
	println new Date()
}


for(i in 0..9) {
	if(isEven(i)) {
		myClosure()
		println i
	}
}

//Function 
/*def isEven(def num) {
	return num%2==0
}*/

def isEven(num) {
	return num%2==0
}




