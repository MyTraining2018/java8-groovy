package org.cap.demo

def names=["tom","jack","Kamal","Tim","Emi","Annie"]
/*for(name in names) {
	println name
}*/

for(i=0;i<names.size();i++) {
	def greetings="Hello! "
	println "$greetings" + names[i]
}