package org.cap.demo

//def num
Integer num
//Integer greet
def greet

println num.getClass()
println greet.getClass()

num=10
greet="Hello"

println num
println greet


println num.getClass()
println greet.getClass()

println ' '

greet=123
println num
println greet

println num.getClass()
println greet.getClass()

