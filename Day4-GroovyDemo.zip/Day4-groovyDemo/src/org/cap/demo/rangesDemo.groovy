package org.cap.demo

/*
def num=3.5
println num 
println 'Welcome'

println num.getClass()*/

def ranges=1..10
for(i in ranges) {
	println i
}

def myChar='a'..'m'
for(ch in myChar)
	print ch + ' '
	
println ' '


def enum WEEKDAYS{
	SUN,
	MON,
	TUE,
	WED,
	THUR,
	FRI,
	SAT
}	

for(day in WEEKDAYS)
	println day


def myDay=WEEKDAYS.TUE..WEEKDAYS.SAT

for(day in myDay)
	println day

println 'Extents:'
println myDay.from
println myDay.to



