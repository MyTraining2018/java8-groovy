package org.cap.demo

def myDate=new Date()
println 'Good Morning!'
println 'Today:' + myDate
println myDate.getClass()