package org.cap.xmldemo

def file=new File("./data/employees.xml")
//println file.exists()

def slurper=new XmlSlurper();
def emps=slurper.parse(file)

emps.employee.each{
	print it.employeeid +  ' '
	 	  it.name + ' '
		   it.address
}