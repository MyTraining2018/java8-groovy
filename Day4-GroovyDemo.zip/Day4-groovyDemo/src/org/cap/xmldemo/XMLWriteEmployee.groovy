package org.cap.xmldemo

def file=new File("./data/employees.xml")
//println file.exists()

def slurper=new XmlSlurper();
def emps=slurper.parse(file)

def markupBuilder = new groovy.xml.StreamingMarkupBuilder()

def xml = markupBuilder.bind{
	employees{
		emps.employee.each{ emp -> 
			employee(employeeid: emp.employeeid.toString()){
			def ename=emp.name.firstname.toString().concat(emp.name.lastname.toString()) 
				println ename
				name(ename.toString())
				
			}
		}
	}
}


def outfile=new File("./data/employees_updated.xml")
outfile.write(xml.toString())
