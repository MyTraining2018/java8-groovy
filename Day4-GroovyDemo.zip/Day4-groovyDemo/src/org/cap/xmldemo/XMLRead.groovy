package org.cap.xmldemo


def file=new File("./data/fells_loop.gpx")
//println file.exists()

def slurper=new XmlSlurper();
def gpx=slurper.parse(file)
//println gpx

println gpx.name
println gpx.desc

println ' '
println gpx.@version
println gpx.@creator

def points=gpx.rte.rtept

/*for(point in points) {
	println point.@lat
	println point.@lon
	println point.ele
	println point.time
	println ' '
}
*/

gpx.rte.rtept.each {
	println it.@lat
	println it.@lon
	println it.time
}

println 'Size:' + points.size()
