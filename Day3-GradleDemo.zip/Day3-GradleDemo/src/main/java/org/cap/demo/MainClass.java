package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		
		System.out.println("Hey! I am working with Gradle!");
		
		if(args.length>0) {
			for(String s:args) {
				System.out.println(s);
			}
		}
		
	}

}
