package org.cap.test1;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyTest {

	@Test
	public void sample() {
		fail("Not yet implemented");
	}

}
